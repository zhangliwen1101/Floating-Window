android-tooltip
===============

android 悬浮窗 完整demo


[欢迎访问我的CSDN博客](http://blog.csdn.net/zz7zz7zz)<br/>


![github](http://img.blog.csdn.net/20131025100023937 "附图一") ![github](http://img.blog.csdn.net/20131025100037375 "附图二")  


