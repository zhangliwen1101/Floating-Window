package com.open.tooltip;

public class ToolTipConfig {

	public static boolean isUseSurfaceView=false;//是否用surface显示动画,true使用,false不使用
	public static boolean isAnimWithShadow=true;//是否显示用户头像阴影
	
}
