package example.aa;

import java.util.List;

import com.zihao.timerdemo.R;

import android.app.Activity;
import android.app.AppOpsManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity
{

    private final static String TAG="MainActivity";
    private final static String AppPackageName="example.maps.android.map.sogou.com.myapplication";
    private final static String SETTINGS_PACKAGE_NAME="com.android.settings";
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Button start = (Button)findViewById(R.id.start_id);
        Button remove = (Button)findViewById(R.id.remove_id);
        start.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(isMIUI()&&!isMiuiFloatWindowOpAllowed(MainActivity.this)){
                    gotoPermissionSettings(MainActivity.this);
                }else{
                    Intent intent = new Intent(MainActivity.this, FloatViewService.class);
                    startService(intent);
//                    finish();
                }
//            	LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
//            	View show_popvieView = inflater.inflate(R.layout.pop_up_window, null);
            }
        });

        remove.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //uninstallApp("com.phicomm.hu");
                Intent intent = new Intent(MainActivity.this, FloatViewService.class);
                stopService(intent);
            }
        });

    }
@Override
protected void onPause() {
	// TODO Auto-generated method stub
	super.onPause();
	 Intent intent = new Intent(MainActivity.this, FloatViewService.class);
     stopService(intent);
}

    /**
     * 打开MIUI权限管理界面(MIUI v5, v6)
     * @param context
     */
//    public static void openMiuiPermissionActivity(Context context) {
//        Intent intent = new Intent("miui.intent.action.APP_PERM_EDITOR");
//        String rom = RomUtils.getRom();
//
//        if (RomUtils.ROM_MIUI_V5.equals(rom)) {
//            PackageInfo pInfo = null;
//            try {
//                pInfo = context.getPackageManager().getPackageInfo(AppPackageName, 0);
//            } catch (PackageManager.NameNotFoundException e) {
//                Log.e(TAG,e.getMessage());
//            }
//            intent.setClassName(SETTINGS_PACKAGE_NAME, "com.miui.securitycenter.permission.AppPermissionsEditor");
//            intent.putExtra("extra_package_uid", pInfo.applicationInfo.uid);
//
//        } else if (RomUtils.ROM_MIUI_V6.equals(rom)) {
//            intent.setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity");
//            intent.putExtra("extra_pkgname", context.getPackageName());
//        }
//
//        if (isIntentAvailable(context, intent)) {
//            if (context instanceof Activity) {
//                Activity a = (Activity) context;
//                a.startActivityForResult(intent, 2);
//            }
//        } else {
//            Log.e(TAG,"Intent is not available!");
//        }
//    }

    /**
     * 打开应用详情页
     * @param context
     * @param packageName
     */
//    public static void openAppDetailActivity(Context context, String packageName) {
//        Intent intent = null;
//        if (Build.VERSION.SDK_INT >= 9) {
//            intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
//            Uri uri = Uri.parse("package:" + packageName);
//            intent.setData(uri);
//        } else {
//            final String className = Build.VERSION.SDK_INT == 8 ? SETTINGS_APPDETAILS_CLASS_NAME_22 : SETTINGS_APPDETAILS_CLASS_NAME_B21;
//            intent = new Intent(Intent.ACTION_VIEW);
//            intent.setClassName(SETTINGS_PACKAGE_NAME, SETTINGS_APPDETAILS_CLASS_NAME);
//            intent.putExtra(className, packageName);
//        }
//        if (isIntentAvailable(context, intent)) {
//            context.startActivity(intent);
//        } else {
//            Log.e(TAG,"intent is not available!");
//        }
//    }


    /**
     * 跳转到应用权限设置页面
     * @param context 传入app 或者 activity context，通过context获取应用packegename，之后通过packegename跳转制定应用
     * @return 是否是miui
     */
    public static boolean gotoPermissionSettings(Context context) {
        boolean mark = isMIUI();
        if ( mark ) {
            // 兼容miui v5/v6  的应用权限设置页面，否则的话跳转应用设置页面（权限设置上一级页面）
            try {
                Intent localIntent = new Intent("miui.intent.action.APP_PERM_EDITOR");
                localIntent.setClassName("com.miui.securitycenter","com.miui.permcenter.permissions.AppPermissionsEditorActivity");
                localIntent.putExtra("extra_pkgname", context.getPackageName());
                context.startActivity(localIntent);
            } catch (ActivityNotFoundException e) {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", context.getPackageName(),null);
                intent.setData(uri);
                context.startActivity(intent);
            }
        }
        return mark;
    }


    /**
     * 判断MIUI的悬浮窗权限
     * @param context
     * @return
     */
    public static boolean isMiuiFloatWindowOpAllowed(Context context) {
        final int version = Build.VERSION.SDK_INT;

        if (version >= 19) {
            return checkOp(context, 24);  //自己写就是24 为什么是24?看AppOpsManager 即AppOpsManager.OP_SYSTEM_ALERT_WINDOW
        } else {
            if ((context.getApplicationInfo().flags & 1<<27) == 1) {
                return true;
            } else {
                return false;
            }
        }
    }

    public static boolean checkOp(Context context, int op) {
        final int version = Build.VERSION.SDK_INT;

        if (version >= 19) {
            AppOpsManager manager = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
            try {
                if (AppOpsManager.MODE_ALLOWED == (Integer)ReflectUtils.invokeMethod(manager, "checkOp", op,
                        Binder.getCallingUid(), context.getPackageName())) {  //这儿反射就自己写吧
                    return true;
                } else {
                    return false;
                }
            } catch (Exception e) {
                Log.e(TAG,e.getMessage());
            }
        } else {
            Log.e(TAG,"Below API 19 cannot invoke!");
        }
        return false;
    }

    /**
     * 检查手机是否是miui
     * @ref http://dev.xiaomi.com/doc/p=254/index.html
     * @return
     */
    public static boolean isMIUI(){
        String device = Build.MANUFACTURER;
        System.out.println( "Build.MANUFACTURER = " + device );
        if ( device.equals( "Xiaomi" ) ) {
            System.out.println( "this is a xiaomi device" );
            return true;
        }
        else{
            return false;
        }
    }


    /**
     * 判断是否是miui V5/V6，老的miui无法兼容
     * @param context
     * @return
     */
    public static boolean isMIUIV5V6(Context context) {
        boolean result = false;
        Intent i = new Intent("miui.intent.action.APP_PERM_EDITOR");
        i.setClassName("com.android.settings", "com.miui.securitycenter.permission.AppPermissionsEditor");
        if (isIntentAvailable(context,i)) {
            result = true;
        }
        return result;
    }

    /**
     * 判断是否有可以接受的Activity
     * @param context
     * @param intent
     * @return
     */
    public static boolean isIntentAvailable(Context context, Intent intent) {
        PackageManager packageManager = context.getPackageManager();
        List<ResolveInfo> list = packageManager.queryIntentActivities(intent,
                PackageManager.GET_ACTIVITIES);
        return list.size() > 0;
    }
}
