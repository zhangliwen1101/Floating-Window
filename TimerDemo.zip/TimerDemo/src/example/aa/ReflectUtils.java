package example.aa;

import android.app.AppOpsManager;

import java.lang.reflect.Method;

/**
 * Created by liudawei on 2015/12/1.
 */
public class ReflectUtils {


    public static int invokeMethod(AppOpsManager manager, String method, int op, int callingUid, String packageName) throws Exception{
        Class<AppOpsManager> clazz = AppOpsManager.class;
        Method dispatchMethod = clazz.getMethod(method, new Class[]{int.class, int.class, String.class});
        int mode = (Integer) dispatchMethod.invoke(manager, new Object[]{op, callingUid, packageName});
        return mode;
    }
}
