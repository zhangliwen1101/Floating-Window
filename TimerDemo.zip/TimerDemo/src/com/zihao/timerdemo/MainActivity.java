package com.zihao.timerdemo;

import com.zihao.service.RegisterCodeTimerService;
import com.zihao.util.RegisterCodeTimer;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;

/**
 * 主界面
 * @author zihao
 */
public class MainActivity extends Activity {

	private Button mGetCodeBtn;// 倒计时按钮
	private Intent mIntent;
	private Button bn1;
	private Button bn2;
	private Button bn3;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		bn1=(Button) findViewById(R.id.bn1);
		bn2=(Button) findViewById(R.id.bn2);
		bn3=(Button) findViewById(R.id.bn3);
		initView();
		bn1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mIntent=new Intent(MainActivity.this, MainActivity1.class);
				startActivity(mIntent);
				finish();
			}
		});
		bn2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mIntent=new Intent(MainActivity.this, example.aa.MainActivity.class);
				startActivity(mIntent);
			}
		});
		bn3.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mIntent=new Intent(MainActivity.this, popwinderActivity.class);
				startActivity(mIntent);
			}
		});
	}

	/**
	 * 初始化视图
	 */
	private void initView() {
		mGetCodeBtn = (Button) findViewById(R.id.get_code_btn);
		RegisterCodeTimerService.setHandler(mCodeHandler);
		mIntent = new Intent(MainActivity.this, RegisterCodeTimerService.class);
		mGetCodeBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mGetCodeBtn.setEnabled(false);
				startService(mIntent);
			}
		});
	}

	/**
	 * 倒计时Handler
	 */
	@SuppressLint("HandlerLeak")
	Handler mCodeHandler = new Handler() {
		public void handleMessage(Message msg) {
			if (msg.what == RegisterCodeTimer.IN_RUNNING) {// 正在倒计时
				mGetCodeBtn.setText(msg.obj.toString());
			} else if (msg.what == RegisterCodeTimer.END_RUNNING) {// 完成倒计时
				mGetCodeBtn.setEnabled(true);
				mGetCodeBtn.setText(msg.obj.toString());
			}
		};
	};

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		stopService(mIntent);
	}
	private ServiceConnection conn = new ServiceConnection() {

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			// TODO Auto-generated method stub
			 
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			// TODO Auto-generated method stub
			
		}
		
	};
}