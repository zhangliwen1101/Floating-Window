package com.zihao.timerdemo;

import com.zihao.util.RegisterCodeTimerService;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity1 extends Activity{
	private Button mGetCodeBtn;// 倒计时按钮
	private final static String TAG="MainActivity1";
	private Intent mIntent;
	private Button bn1;
	private Button get_code_btn;
	
	  private final BroadcastReceiver mUpdateReceiver = new BroadcastReceiver() {
	        @Override
	        public void onReceive(Context context, Intent intent) {
	            final String action = intent.getAction();
	            switch (action) {
	                case RegisterCodeTimerService.IN_RUNNING:
	                    if (bn1.isEnabled())
	                    	bn1.setEnabled(false);
	                    // 正在倒计时
	                    bn1.setText("倒计时中(" + intent.getStringExtra("time") + ")");
	                    Log.e(TAG, "倒计时中(" + intent.getStringExtra("time") + ")");
	                    break;
	                case RegisterCodeTimerService.END_RUNNING:
	                    // 完成倒计时
	                	bn1.setEnabled(true);
	                	bn1.setText("点击发送");
	                    break;
	            }
	        }
	    };
	    @Override
	    protected void onResume() {
	        super.onResume();
	        // 注册广播
	        registerReceiver(mUpdateReceiver, updateIntentFilter());
	    }
	   // 注册广播
	    private static IntentFilter updateIntentFilter() {
	        final IntentFilter intentFilter = new IntentFilter();
	        intentFilter.addAction(RegisterCodeTimerService.IN_RUNNING);
	        intentFilter.addAction(RegisterCodeTimerService.END_RUNNING);
	        return intentFilter;
	    }
	    @Override
	    protected void onPause() {
	        super.onPause();
	        // 移除注册
	        unregisterReceiver(mUpdateReceiver);
	    }
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		get_code_btn=(Button) findViewById(R.id.get_code_btn);
		bn1=(Button) findViewById(R.id.bn1);
		mIntent = new Intent(MainActivity1.this, RegisterCodeTimerService.class);
		get_code_btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mIntent=new Intent(MainActivity1.this, MainActivity.class);
				startActivity(mIntent);
				finish();
			}
		});
		bn1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// 将按钮设置为不可用状态
				bn1.setEnabled(false);
                // 启动倒计时的服务
				startService(mIntent);
			}
		});
	}
}
