package com.zihao.timerdemo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.zihao.util.ImageOptions;

public class popwinderActivity extends Activity {
	private static final String TAG = "popwinderActivity";
	private PopupWindow popupWindow;
	private Button bn1;
	private LayoutInflater inflater;
	private View show_popvieView;
	private ImageView image;
	private LinearLayout linear;
	private int width = 0;// button控件的宽
	private int height = 0;// button控件的高
	private int screen_width = 0;// 屏幕的的宽
	private int screen_height = 0;// 屏幕的高
	private DisplayImageOptions m_options;
	
	private Handler mHander = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 0x11:
				// 可以动态获取图片的宽高，再把宽高当做PopupWindow的参数设置进去就OK了
				popupWindow = new PopupWindow(show_popvieView, 80, 80);
				// popupWindow.setBackgroundDrawable(getResources().getDrawable(R.drawable.index_pre));
				popupWindow.setFocusable(false);
				popupWindow.setOutsideTouchable(false);
				popupWindow.setTouchable(true);
				System.out.println("dasdasdasdas:" + width);
				/*
				 * 第一个参数，如果是相对于某一个控件去展示popupWindow那么在页面ScrollView滑动时，
				 * popupWindow也会跟着滑动（下面第一种情况）
				 * 第一个参数，如果是相对于整个页面去展示popupWindow那么在页面ScrollView滑动时
				 * ，popupWindow不会跟着滑动（下面第二种情况）
				 */
				// popupWindow.showAsDropDown(findViewById(R.id.bn1), width/6,
				// 0);//相对于第一个参数，向第一个参数空间为标准向X轴Y轴移动
				popupWindow.showAsDropDown(findViewById(R.id.linear),
						screen_width / 6, -screen_height / 2);// 相对于第一个参数，向第一个参数空间为标准向X轴Y轴移动
				break;

			default:
				break;
			}
		}

	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.popwinder);
		bn1 = (Button) findViewById(R.id.bn1);
		linear = (LinearLayout) findViewById(R.id.linear);
		inflater = LayoutInflater.from(this);
		show_popvieView = inflater.inflate(R.layout.imgview, null);
		image = (ImageView) show_popvieView.findViewById(R.id.image);
		getScreenWidthHeight();
		initOnLayoutListener();
		
		m_options = ImageOptions.getLogoOptions(true);
		
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(getApplicationContext())
		                             .build();
		                         ImageLoader.getInstance().init(config);
		ImageLoader.getInstance().displayImage(
		                                "http://od6ro0ups.bkt.clouddn.com/new_year.png",
		                                image, m_options);

		image.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(popwinderActivity.this, "11111111", 1).show();
			}
		});
		mHander.sendEmptyMessageDelayed(0x11, 1000);// 延迟一秒钟展示
	}

	/**
	 * 为Activity的布局文件添加OnGlobalLayoutListener事件监听，
	 * 当回调到onGlobalLayout方法的时候我们通过getMeasureHeight和getMeasuredWidth方法可以获取到组件的宽和高
	 */
	private void initOnLayoutListener() {
		final ViewTreeObserver viewTreeObserver = this.getWindow()
				.getDecorView().getViewTreeObserver();
		viewTreeObserver
				.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
					@SuppressLint("NewApi")
					@Override
					public void onGlobalLayout() {
						Log.i(TAG, "开始执行onGlobalLayout().........");
						height = bn1.getMeasuredHeight();
						width = bn1.getMeasuredWidth();
						System.out
								.println("asdasdas" + width + "    " + height);
						Log.i(TAG, "height:" + height + "   width:" + width);
						// 移除GlobalLayoutListener监听
						popwinderActivity.this.getWindow().getDecorView()
								.getViewTreeObserver()
								.removeOnGlobalLayoutListener(this);
					}
				});
	}

	private void getScreenWidthHeight() {

		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		screen_width = dm.widthPixels;
		screen_height = dm.heightPixels;

	}
}
